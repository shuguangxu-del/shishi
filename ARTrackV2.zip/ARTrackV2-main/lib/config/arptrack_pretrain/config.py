from easydict import EasyDict as edict
import yaml

cfg = edict()

cfg.MODEL = edict()
cfg.MODEL.PRETRAIN_FILE = "mae_pretrain_vit_base.pth"
cfg.MODEL.PRETRAIN_PTH = ""
cfg.MODEL.EXTRA_MERGER = False

cfg.MODEL.BACKBONE = edict()
cfg.MODEL.BACKBONE.TYPE = "vit_base_patch16_224"
cfg.MODEL.BACKBONE.STRIDE = 16
cfg.MODEL.BACKBONE.MID_PE = False
cfg.MODEL.BACKBONE.SEP_SEG = False
cfg.MODEL.BACKBONE.CAT_MODE = 'direct'
cfg.MODEL.BACKBONE.MERGE_LAYER = 0
cfg.MODEL.BACKBONE.ADD_CLS_TOKEN = False
cfg.MODEL.BACKBONE.CLS_TOKEN_USE_MODE = 'ignore'

cfg.MODEL.BACKBONE.CE_LOC = []
cfg.MODEL.BACKBONE.CE_KEEP_RATIO = []
cfg.MODEL.BACKBONE.CE_TEMPLATE_RANGE = 'ALL'

cfg.MODEL.BINS = 400
cfg.MODEL.RANGE = 2
cfg.MODEL.EXTENSION = 3
cfg.MODEL.ENCODER_LAYER = 3
cfg.MODEL.NUM_HEADS = 12
cfg.MODEL.MLP_RATIO = 4
cfg.MODEL.QKV_BIAS = True
cfg.MODEL.DROP_RATE = 0.1
cfg.MODEL.ATTN_DROP = 0.0
cfg.MODEL.DROP_PATH = 0.0
cfg.MODEL.DECODER_LAYER = 6

cfg.MODEL.DIFFUSION = edict()
cfg.MODEL.DIFFUSION.TIMESTEPS = 1000
cfg.MODEL.DIFFUSION.IN_CHANNELS = 768
cfg.MODEL.DIFFUSION.COND_CHANNELS = 5376

cfg.MODEL.BACKTRACKING = edict()
cfg.MODEL.BACKTRACKING.HIDDEN_DIM = 512
cfg.MODEL.BACKTRACKING.NUM_LAYERS = 2

cfg.TRAIN = edict()
cfg.TRAIN.LR = 0.0001
cfg.TRAIN.WEIGHT_DECAY = 0.0001
cfg.TRAIN.EPOCH = 200
cfg.TRAIN.LR_DROP_EPOCH = 150
cfg.TRAIN.BATCH_SIZE = 8
cfg.TRAIN.NUM_WORKER = 6
cfg.TRAIN.OPTIMIZER = "ADAMW"
cfg.TRAIN.BACKBONE_MULTIPLIER = 0.1
cfg.TRAIN.PRINT_INTERVAL = 50
cfg.TRAIN.GRAD_CLIP_NORM = 0.1
cfg.TRAIN.AMP = False
cfg.TRAIN.DIFFUSION_WEIGHT = 1.0
cfg.TRAIN.BACKTRACK_L1_WEIGHT = 1.0
cfg.TRAIN.BACKTRACK_GIOU_WEIGHT = 2.0

cfg.TRAIN.SCHEDULER = edict()
cfg.TRAIN.SCHEDULER.TYPE = "step"
cfg.TRAIN.SCHEDULER.DECAY_RATE = 0.1

cfg.DATA = edict()
cfg.DATA.MEAN = [0.485, 0.456, 0.406]
cfg.DATA.STD = [0.229, 0.224, 0.225]

cfg.DATA.TRAIN = edict()
cfg.DATA.TRAIN.DATASETS_NAME = ["LASOT", "GOT10K_vottrain"]
cfg.DATA.TRAIN.DATASETS_RATIO = [1, 1]
cfg.DATA.TRAIN.SAMPLE_PER_EPOCH = 40000

cfg.DATA.PRETRAIN = edict()
cfg.DATA.PRETRAIN.HISTORY_FRAMES = 2
cfg.DATA.PRETRAIN.FUTURE_FRAMES = 1
cfg.DATA.PRETRAIN.HISTORY_SIZE = 224
cfg.DATA.PRETRAIN.FUTURE_SIZE = 224
cfg.DATA.PRETRAIN.SAMPLER_MODE = 'sequential'
cfg.DATA.PRETRAIN.MAX_INTERVAL = 10

cfg.TEST = edict()
cfg.TEST.EPOCH = 200


def _edict2dict(dest_dict, src_edict):
    if isinstance(dest_dict, dict) and isinstance(src_edict, dict):
        for k, v in src_edict.items():
            if not isinstance(v, edict):
                dest_dict[k] = v
            else:
                dest_dict[k] = {}
                _edict2dict(dest_dict[k], v)
    else:
        return


def gen_config(config_file):
    cfg_dict = {}
    _edict2dict(cfg_dict, cfg)
    with open(config_file, 'w') as f:
        yaml.dump(cfg_dict, f, default_flow_style=False)


def _update_config(base_cfg, exp_cfg):
    if isinstance(base_cfg, dict) and isinstance(exp_cfg, edict):
        for k, v in exp_cfg.items():
            if k in base_cfg:
                if not isinstance(v, dict):
                    base_cfg[k] = v
                else:
                    _update_config(base_cfg[k], v)
            else:
                raise ValueError("{} not exist in config.py".format(k))
    else:
        return


def update_config_from_file(filename, base_cfg=None):
    exp_config = None
    with open(filename) as f:
        exp_config = edict(yaml.safe_load(f))
        if base_cfg is not None:
            _update_config(base_cfg, exp_config)
        else:
            _update_config(cfg, exp_config)
