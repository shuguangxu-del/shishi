import os
import torch
from torch.nn.functional import l1_loss
from torch import nn

from lib.train.trainers import ARPTrainer
from lib.train.data.pretrain_processing import jittered_crop_safe
from lib.train.data import opencv_loader
from lib.train.data.sequence_sampler_pretrain import PretrainSequenceSampler
from lib.train.train_script import names2datasets
from lib.models.arptrack import build_arptrack
from lib.train.actors.arptrack_pretrain import ARPTrackPretrainActor
from .base_functions import update_settings
from torch.nn.parallel import DistributedDataParallel as DDP

import importlib


def run(settings):
    if not os.path.exists(settings.cfg_file):
        raise ValueError("%s doesn't exist." % settings.cfg_file)
    config_module = importlib.import_module("lib.config.%s.config" % settings.script_name)
    cfg = config_module.cfg
    config_module.update_config_from_file(settings.cfg_file)
    update_settings(settings, cfg)

    log_dir = os.path.join(settings.save_dir, 'logs')
    if settings.local_rank in [-1, 0]:
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
    settings.log_file = os.path.join(log_dir, "%s-%s.log" % (settings.script_name, settings.config_name))

    net = build_arptrack(cfg)
    dataset_train = PretrainSequenceSampler(
        datasets=names2datasets(cfg.DATA.TRAIN.DATASETS_NAME, settings, opencv_loader),
        p_datasets=cfg.DATA.TRAIN.DATASETS_RATIO,
        samples_per_epoch=cfg.DATA.TRAIN.SAMPLE_PER_EPOCH,
        num_history_frames=cfg.DATA.PRETRAIN.HISTORY_FRAMES,
        num_future_frames=cfg.DATA.PRETRAIN.FUTURE_FRAMES,
        frame_sample_mode=cfg.DATA.PRETRAIN.SAMPLER_MODE,
        max_interval=cfg.DATA.PRETRAIN.MAX_INTERVAL,
        max_history_frames=cfg.DATA.PRETRAIN.MAX_HISTORY_FRAMES,
    )

    loader_train = torch.utils.data.DataLoader(
        dataset_train,
        batch_size=cfg.TRAIN.BATCH_SIZE,
        shuffle=True,
        num_workers=cfg.TRAIN.NUM_WORKER,
        drop_last=True,
    )

    net.cuda()
    if settings.local_rank != -1:
        net = DDP(net, device_ids=[settings.local_rank], find_unused_parameters=True)
        settings.device = torch.device("cuda:%d" % settings.local_rank)
    else:
        settings.device = torch.device("cuda:0")

    objective = {
        'diffusion': nn.MSELoss(),
        'l1': l1_loss,
    }
    loss_weight = {
        'diffusion': cfg.TRAIN.DIFFUSION_WEIGHT,
        'backtrack_l1': cfg.TRAIN.BACKTRACK_L1_WEIGHT,
        'backtrack_giou': cfg.TRAIN.BACKTRACK_GIOU_WEIGHT,
    }

    actor = ARPTrackPretrainActor(net=net, objective=objective, loss_weight=loss_weight, settings=settings, cfg=cfg)

    optimizer = torch.optim.AdamW(net.parameters(), lr=cfg.TRAIN.LR, weight_decay=cfg.TRAIN.WEIGHT_DECAY)
    lr_scheduler = torch.optim.lr_scheduler.StepLR(optimizer, cfg.TRAIN.LR_DROP_EPOCH)

    trainer = ARPTrainer(actor, [loader_train], optimizer, settings, lr_scheduler, use_amp=cfg.TRAIN.AMP)
    trainer.train(cfg.TRAIN.EPOCH, load_latest=True, fail_safe=True)
