import random
import torch
import torch.nn.functional as F
import numpy as np
import lib.train.data.processing_utils as prutils


def _clamp_jitter(box, frame_size, max_translation, max_scale):
    x, y, w, h = box
    H, W = frame_size
    cx = x + 0.5 * w
    cy = y + 0.5 * h

    jitter_tx = (random.random() * 2 - 1) * max_translation * w
    jitter_ty = (random.random() * 2 - 1) * max_translation * h

    scale = 1.0 + (random.random() * 2 - 1) * max_scale
    scale = max(1.0 - max_scale, min(1.0 + max_scale, scale))

    new_w = w * scale
    new_h = h * scale

    max_cx = W - 0.5 * new_w
    min_cx = 0.5 * new_w
    max_cy = H - 0.5 * new_h
    min_cy = 0.5 * new_h

    new_cx = min(max(cx + jitter_tx, min_cx), max_cx)
    new_cy = min(max(cy + jitter_ty, min_cy), max_cy)

    new_x = min(max(new_cx - 0.5 * new_w, 0.0), W - new_w)
    new_y = min(max(new_cy - 0.5 * new_h, 0.0), H - new_h)

    return torch.tensor([new_x, new_y, new_w, new_h])


def jittered_crop_safe(frames, boxes, output_sz, search_area_factor, max_translation=0.2, max_scale=0.3):
    """Apply constrained jitter/scale ensuring bbox stays fully visible."""
    jittered = []
    for frame, box in zip(frames, boxes):
        w, h = box[2], box[3]
        if w <= 1 or h <= 1:
            jittered.append(box)
            continue
        frame_size = frame.shape[0], frame.shape[1]
        jittered.append(_clamp_jitter(box, frame_size, max_translation, max_scale))

    crops, boxes_crop, att_mask, _ = prutils.jittered_center_crop(
        frames,
        jittered,
        boxes,
        search_area_factor,
        output_sz,
        masks=None,
    )

    crops = torch.from_numpy(np.stack(crops)).permute(0, 3, 1, 2).float() / 255.0
    boxes_crop = torch.stack(boxes_crop)
    return crops, boxes_crop
