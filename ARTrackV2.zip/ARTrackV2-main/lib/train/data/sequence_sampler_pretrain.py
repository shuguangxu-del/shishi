import random
import torch.utils.data
import numpy as np
from lib.utils import TensorDict


class PretrainSequenceSampler(torch.utils.data.Dataset):
    """Sampler for ARP pretraining with history/future clips."""

    def __init__(self, datasets, p_datasets, samples_per_epoch, num_history_frames, num_future_frames,
                 frame_sample_mode='sequential', max_interval=50, max_history_frames=7):
        self.datasets = datasets
        if p_datasets is None:
            p_datasets = [len(d) for d in self.datasets]
        p_total = sum(p_datasets)
        self.p_datasets = [x / p_total for x in p_datasets]
        self.samples_per_epoch = samples_per_epoch
        self.num_history_frames = num_history_frames
        self.num_future_frames = num_future_frames
        self.max_history_frames = max_history_frames
        self.frame_sample_mode = frame_sample_mode
        self.max_interval = max_interval
        self.current_epoch = 0

    def set_epoch(self, epoch):
        self.current_epoch = epoch

    def _current_history_frames(self):
        return min(2 + self.current_epoch // 100, self.max_history_frames)

    def __len__(self):
        return self.samples_per_epoch

    def _sample_visible_ids(self, visible, num_ids=1, min_id=None, max_id=None):
        if num_ids == 0:
            return []
        if min_id is None or min_id < 0:
            min_id = 0
        if max_id is None or max_id > len(visible):
            max_id = len(visible)
        valid_ids = [i for i in range(min_id, max_id) if visible[i]]
        if len(valid_ids) == 0:
            return None
        return random.choices(valid_ids, k=num_ids)

    def _sequential_sample(self, visible, history_frames):
        history_ids = self._sample_visible_ids(
            visible,
            num_ids=history_frames,
            min_id=0,
            max_id=len(visible) - self.num_future_frames,
        )
        if history_ids is None:
            return None, None
        last_hist = max(history_ids)
        future_start = min(last_hist + 1, len(visible) - self.num_future_frames)
        future_ids = list(range(future_start, future_start + self.num_future_frames))
        return history_ids, future_ids

    def _interval_sample(self, visible, history_frames):
        valid_ids = [i for i in range(len(visible)) if visible[i]]
        if len(valid_ids) < history_frames + self.num_future_frames:
            return None, None
        start = random.choice(valid_ids[:-self.num_future_frames])
        history_ids = list(range(start, start + history_frames))
        future_start = min(start + history_frames, len(visible) - self.num_future_frames)
        future_ids = list(range(future_start, future_start + self.num_future_frames))
        return history_ids, future_ids

    def __getitem__(self, index):
        dataset = random.choices(self.datasets, self.p_datasets)[0]
        is_video_dataset = dataset.is_video_sequence()

        history_frames = self._current_history_frames()

        enough_visible_frames = False
        while not enough_visible_frames:
            seq_id = random.randint(0, dataset.get_num_sequences() - 1)
            seq_info_dict = dataset.get_sequence_info(seq_id)
            visible = seq_info_dict['visible']
            enough_visible_frames = visible.type(torch.int64).sum().item() > (
                history_frames + self.num_future_frames
            ) and len(visible) >= (history_frames + self.num_future_frames)
            enough_visible_frames = enough_visible_frames or not is_video_dataset

        if is_video_dataset:
            if self.frame_sample_mode == 'sequential':
                history_ids, future_ids = self._sequential_sample(visible, history_frames)
            else:
                history_ids, future_ids = self._interval_sample(visible, history_frames)
        else:
            history_ids = [1] * history_frames
            future_ids = [1] * self.num_future_frames

        history_frames, history_anno, _ = dataset.get_frames(seq_id, history_ids, seq_info_dict)
        future_frames, future_anno, _ = dataset.get_frames(seq_id, future_ids, seq_info_dict)

        history_bbox = [bbox.numpy() for bbox in history_anno['bbox']]
        future_bbox = [bbox.numpy() for bbox in future_anno['bbox']]

        return TensorDict({
            'history_images': np.array(history_frames),
            'history_annos': np.array(history_bbox),
            'future_images': np.array(future_frames),
            'future_annos': np.array(future_bbox),
            'seq_id': seq_id,
            'dataset': dataset.get_name(),
        })
