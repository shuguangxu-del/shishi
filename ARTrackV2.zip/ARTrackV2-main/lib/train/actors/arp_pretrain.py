from copy import deepcopy
import torch
from . import BaseActor
from lib.utils.box_ops import box_xywh_to_xyxy, giou_loss


class ARPPretrainActor(BaseActor):
    def __init__(self, net, objective, loss_weight, settings, cfg=None):
        super().__init__(net, objective)
        self.loss_weight = loss_weight
        self.settings = settings
        self.cfg = cfg

    def __call__(self, data):
        out_dict = self.forward_pass(data)
        loss, status = self.compute_losses(out_dict, data)
        return loss, status

    def forward_pass(self, data):
        history_images = data['history_images']
        future_images = data['future_images']
        history_bbox = data['history_annos']
        future_bbox = data['future_annos']

        history_embeddings = history_images.flatten(1)
        future_embeddings = future_images.flatten(1)

        diffusion_timesteps = torch.randint(
            low=0,
            high=self.cfg.MODEL.DIFFUSION.TIMESTEPS,
            size=(future_embeddings.shape[0],),
            device=future_embeddings.device,
        )

        template_list = [history_images[:, 0], history_images[:, 0]]
        out = self.net(
            template=template_list,
            search=future_images[:, 0],
            history_embeddings=history_embeddings,
            future_embeddings=future_embeddings,
            diffusion_timesteps=diffusion_timesteps,
        )

        out['history_bbox'] = history_bbox
        out['future_bbox'] = future_bbox
        return out

    def compute_losses(self, pred_dict, data, return_status=True):
        diffusion_noise = pred_dict['diffusion_noise']
        diffusion_noise_pred = pred_dict['diffusion_noise_pred']
        diffusion_loss = self.objective['diffusion'](diffusion_noise_pred, diffusion_noise)

        backtracking_pred = pred_dict['backtracking_boxes']
        history_bbox = torch.tensor(pred_dict['history_bbox']).to(backtracking_pred)
        history_bbox_xyxy = box_xywh_to_xyxy(history_bbox)
        backtracking_l1 = self.objective['l1'](backtracking_pred, history_bbox)
        giou, _ = giou_loss(box_xywh_to_xyxy(backtracking_pred), history_bbox_xyxy)

        loss = self.loss_weight['diffusion'] * diffusion_loss + \
               self.loss_weight['backtrack_l1'] * backtracking_l1 + \
               self.loss_weight['backtrack_giou'] * giou

        if return_status:
            status = {
                'Loss/total': loss.item(),
                'Loss/diffusion': diffusion_loss.item(),
                'Loss/backtrack_l1': backtracking_l1.item(),
                'Loss/backtrack_giou': giou.item(),
            }
            return loss, status
        return loss
