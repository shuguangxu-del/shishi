from lib.train.trainers import LTRTrainer


class ARPTrainer(LTRTrainer):
    """Trainer with progressive sequence length schedule."""

    def train_epoch(self):
        for loader in self.loaders:
            if self.epoch % loader.epoch_interval == 0:
                if hasattr(loader.dataset, "set_epoch"):
                    loader.dataset.set_epoch(self.epoch)
                self.cycle_dataset(loader)

        self._stats_new_epoch()
