from functools import partial

import torch
import torch.nn as nn
from timm.models.layers import DropPath, to_2tuple, trunc_normal_

from lib.models.layers.patch_embed import PatchEmbed
from .utils import generate_arp_mask, add_temporal_embeddings


class BaseBackbone(nn.Module):
    def __init__(self):
        super().__init__()
        self.pos_embed = None
        self.img_size = [224, 224]
        self.patch_size = 16
        self.embed_dim = 384

        self.pos_embed_history = None
        self.pos_embed_future = None

        self.temporal_embed = None
        self.tokens_per_frame = None
        self.max_temporal_len = None

    def finetune_track(self, cfg, patch_start_index=1):
        history_size = to_2tuple(cfg.DATA.PRETRAIN.HISTORY_SIZE)
        future_size = to_2tuple(cfg.DATA.PRETRAIN.FUTURE_SIZE)
        new_patch_size = cfg.MODEL.BACKBONE.STRIDE

        if new_patch_size != self.patch_size:
            old_patch_embed = {}
            for name, param in self.patch_embed.named_parameters():
                if 'weight' in name:
                    param = nn.functional.interpolate(param, size=(new_patch_size, new_patch_size),
                                                      mode='bicubic', align_corners=False)
                    param = nn.Parameter(param)
                old_patch_embed[name] = param
            self.patch_embed = PatchEmbed(img_size=self.img_size, patch_size=new_patch_size, in_chans=3,
                                          embed_dim=self.embed_dim)
            self.patch_embed.proj.bias = old_patch_embed['proj.bias']
            self.patch_embed.proj.weight = old_patch_embed['proj.weight']

        patch_pos_embed = self.pos_embed[:, patch_start_index:, :]
        patch_pos_embed = patch_pos_embed.transpose(1, 2)
        B, E, Q = patch_pos_embed.shape
        P_H, P_W = self.img_size[0] // self.patch_size, self.img_size[1] // self.patch_size
        patch_pos_embed = patch_pos_embed.view(B, E, P_H, P_W)

        H, W = history_size
        new_P_H, new_P_W = H // new_patch_size, W // new_patch_size
        history_patch_pos_embed = nn.functional.interpolate(patch_pos_embed, size=(new_P_H, new_P_W), mode='bicubic',
                                                            align_corners=False)
        history_patch_pos_embed = history_patch_pos_embed.flatten(2).transpose(1, 2)

        H, W = future_size
        new_P_H, new_P_W = H // new_patch_size, W // new_patch_size
        future_patch_pos_embed = nn.functional.interpolate(patch_pos_embed, size=(new_P_H, new_P_W), mode='bicubic',
                                                           align_corners=False)
        future_patch_pos_embed = future_patch_pos_embed.flatten(2).transpose(1, 2)

        self.pos_embed_history = nn.Parameter(history_patch_pos_embed)
        self.pos_embed_future = nn.Parameter(future_patch_pos_embed)
        self.tokens_per_frame = history_patch_pos_embed.shape[1]

        self.max_temporal_len = cfg.DATA.PRETRAIN.MAX_TEMPORAL_LEN
        self.temporal_embed = nn.Parameter(torch.zeros(1, self.max_temporal_len, 1, self.embed_dim))
        trunc_normal_(self.temporal_embed, std=.02)

    def forward_tokens(self, history, future, task_type="appearance"):
        B, Th, C, Hh, Wh = history.shape
        Bf, Tf, Cf, Hf, Wf = future.shape

        history = history.reshape(B * Th, C, Hh, Wh)
        future = future.reshape(B * Tf, Cf, Hf, Wf)

        history = self.patch_embed(history).reshape(B, Th, -1, self.embed_dim)
        future = self.patch_embed(future).reshape(B, Tf, -1, self.embed_dim)

        history = history + self.pos_embed_history
        future = future + self.pos_embed_future

        total_frames = Th + Tf
        temporal_embed = self.temporal_embed[:, :total_frames]
        history = add_temporal_embeddings(history, temporal_embed[:, :Th])
        future = add_temporal_embeddings(future, temporal_embed[:, Th:Th + Tf])

        tokens = torch.cat([history, future], dim=1)
        tokens = tokens.reshape(B, total_frames * tokens.shape[2], self.embed_dim)
        mask = generate_arp_mask(total_frames, tokens.shape[1] // total_frames, task_type=task_type, device=tokens.device)

        return tokens, mask
