import torch


def generate_arp_mask(num_frames: int, tokens_per_frame: int, task_type: str = "appearance", device=None):
    total_tokens = num_frames * tokens_per_frame
    mask = torch.zeros(total_tokens, total_tokens, dtype=torch.bool, device=device)
    time_indices = torch.arange(num_frames, device=device).repeat_interleave(tokens_per_frame)

    if task_type == "appearance":
        future_block = time_indices[None, :] > time_indices[:, None]
        mask |= future_block
    elif task_type == "trajectory":
        past_block = time_indices[None, :] < time_indices[:, None]
        mask |= past_block
    else:
        raise ValueError(f"Unknown task_type: {task_type}")

    return mask


def add_temporal_embeddings(tokens, temporal_embed):
    """
    tokens: (B, T, L, C)
    temporal_embed: (1, T, 1, C)
    """
    return tokens + temporal_embed
