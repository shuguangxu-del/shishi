import os
import torch
from torch import nn
from timm.models.layers import trunc_normal_

from .vit import vit_base_patch16_224, vit_large_patch16_224
from .diffusion import ARPResidualDiffusion
from .heads import BacktrackingHead


class ARPTrack(nn.Module):
    def __init__(self, backbone, diffusion_module, backtracking_head, max_history_frames=7):
        super().__init__()
        self.identity = torch.nn.Parameter(torch.zeros(1, 3, backbone.embed_dim))
        self.identity = trunc_normal_(self.identity, std=.02)
        self.backbone = backbone
        self.diffusion_module = diffusion_module
        self.backtracking_head = backtracking_head
        self.max_history_frames = max_history_frames

    def _tokens_to_feature_map(self, tokens, num_frames=1):
        """tokens: [B, L, C] or [B, T*L, C] -> [B, C*T, H, W] with zero padding."""
        B, L, C = tokens.shape
        tokens_per_frame = L // num_frames
        side = int(tokens_per_frame ** 0.5)
        feat = tokens.reshape(B, num_frames, tokens_per_frame, C)
        feat = feat.reshape(B, num_frames, side, side, C).permute(0, 1, 4, 2, 3)

        if num_frames < self.max_history_frames:
            pad_frames = self.max_history_frames - num_frames
            pad = torch.zeros((B, pad_frames, C, side, side), device=tokens.device, dtype=tokens.dtype)
            feat = torch.cat([feat, pad], dim=1)

        feat = feat.reshape(B, -1, side, side)
        return feat

    def forward(self, template, search, history_embeddings=None, future_embeddings=None, diffusion_timesteps=None,
                task_type="appearance", history_images=None, future_images=None,
                current_feat=None, future_feat=None, history_feat=None):
        outputs = {}

        if history_images is not None and future_images is not None:
            history_feat_out, future_feat_out = self.backbone(history_images, future_images, task_type=task_type)
            outputs["history_feat"] = history_feat_out
            outputs["future_feat"] = future_feat_out

            tokens_per_frame = history_feat_out.shape[1] // history_images.shape[1]
            outputs["current_tokens"] = history_feat_out[:, -tokens_per_frame:, :]

            if "current_tokens" in outputs:
                current_feat = self._tokens_to_feature_map(outputs["current_tokens"], num_frames=1)
            if "future_feat" in outputs:
                future_feat = self._tokens_to_feature_map(outputs["future_feat"], num_frames=1)
            if "history_feat" in outputs:
                history_feat = self._tokens_to_feature_map(outputs["history_feat"], num_frames=history_images.shape[1])

        if current_feat is not None and future_feat is not None and history_feat is not None:
            diffusion_loss = self.diffusion_module.forward_train(future_feat, current_feat, history_feat)
            outputs["diffusion_loss"] = diffusion_loss

        if current_feat is not None and history_feat is not None:
            diffusion_pred = self.diffusion_module.sample_ddim(current_feat, history_feat)
            outputs["diffusion_pred"] = diffusion_pred

        if "future_feat" in outputs:
            pooled_feat = outputs["future_feat"].mean(dim=1)
            outputs["backtracking_boxes"] = self.backtracking_head(pooled_feat)

        return outputs


def build_arptrack(cfg, training=True):
    current_dir = os.path.dirname(os.path.abspath(__file__))
    pretrained_path = os.path.join(current_dir, '../../../pretrained_models')
    if cfg.MODEL.PRETRAIN_FILE and ('ARTrack' not in cfg.MODEL.PRETRAIN_FILE) and training:
        pretrained = os.path.join(pretrained_path, cfg.MODEL.PRETRAIN_FILE)
    else:
        pretrained = ''

    if cfg.MODEL.BACKBONE.TYPE == 'vit_base_patch16_224':
        backbone = vit_base_patch16_224(pretrained, drop_path_rate=cfg.TRAIN.DROP_PATH_RATE,
                                        bins=cfg.MODEL.BINS, range=cfg.MODEL.RANGE,
                                        extension=cfg.MODEL.EXTENSION)
        hidden_dim = backbone.embed_dim
        patch_start_index = 1
    elif cfg.MODEL.BACKBONE.TYPE == 'vit_large_patch16_224':
        backbone = vit_large_patch16_224(pretrained, drop_path_rate=cfg.TRAIN.DROP_PATH_RATE,
                                         bins=cfg.MODEL.BINS, range=cfg.MODEL.RANGE,
                                         extension=cfg.MODEL.EXTENSION)
        hidden_dim = backbone.embed_dim
        patch_start_index = 1
    else:
        raise NotImplementedError

    backbone.finetune_track(cfg=cfg, patch_start_index=patch_start_index)

    diffusion_module = ARPResidualDiffusion(
        in_channels=cfg.MODEL.DIFFUSION.IN_CHANNELS,
        cond_channels=cfg.MODEL.DIFFUSION.COND_CHANNELS,
        num_timesteps=cfg.MODEL.DIFFUSION.TIMESTEPS,
    )
    backtracking_head = BacktrackingHead(hidden_dim, cfg.MODEL.BACKTRACKING.HIDDEN_DIM, cfg.MODEL.BACKTRACKING.NUM_LAYERS)

    model = ARPTrack(backbone, diffusion_module, backtracking_head, max_history_frames=cfg.DATA.PRETRAIN.MAX_HISTORY_FRAMES)

    return model
