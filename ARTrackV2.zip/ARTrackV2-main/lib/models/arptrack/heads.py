import torch
from torch import nn


class BacktrackingHead(nn.Module):
    def __init__(self, in_dim: int, hidden_dim: int, num_layers: int = 2):
        super().__init__()
        layers = []
        for i in range(num_layers - 1):
            layers.extend([nn.Linear(in_dim if i == 0 else hidden_dim, hidden_dim), nn.GELU()])
        layers.append(nn.Linear(hidden_dim if num_layers > 1 else in_dim, 4))
        self.net = nn.Sequential(*layers)

    def forward(self, features):
        return self.net(features)
