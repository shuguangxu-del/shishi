import math
import torch
import torch.nn as nn


# ====================================================
# 1. 基础模块 (保留自 DDIM 源码，适配 ARPTrack)
# ====================================================

def get_timestep_embedding(timesteps, embedding_dim):
    assert len(timesteps.shape) == 1
    half_dim = embedding_dim // 2
    emb = math.log(10000) / (half_dim - 1)
    emb = torch.exp(torch.arange(half_dim, dtype=torch.float32, device=timesteps.device) * -emb)
    emb = timesteps.float()[:, None] * emb[None, :]
    emb = torch.cat([torch.sin(emb), torch.cos(emb)], dim=1)
    if embedding_dim % 2 == 1:
        emb = torch.nn.functional.pad(emb, (0, 1, 0, 0))
    return emb


def nonlinearity(x):
    return x * torch.sigmoid(x)


def Normalize(in_channels):
    return torch.nn.GroupNorm(num_groups=32, num_channels=in_channels, eps=1e-6, affine=True)


class ResnetBlock(nn.Module):
    def __init__(self, *, in_channels, out_channels=None, conv_shortcut=False, dropout=0.1, temb_channels=512):
        super().__init__()
        self.in_channels = in_channels
        out_channels = in_channels if out_channels is None else out_channels
        self.out_channels = out_channels
        self.use_conv_shortcut = conv_shortcut

        self.norm1 = Normalize(in_channels)
        self.conv1 = torch.nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=1)
        self.temb_proj = torch.nn.Linear(temb_channels, out_channels)
        self.norm2 = Normalize(out_channels)
        self.dropout = torch.nn.Dropout(dropout)
        self.conv2 = torch.nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=1, padding=1)
        if self.in_channels != self.out_channels:
            self.shortcut = torch.nn.Conv2d(in_channels, out_channels, kernel_size=3 if conv_shortcut else 1,
                                            stride=1, padding=1 if conv_shortcut else 0)

    def forward(self, x, temb):
        h = x
        h = self.norm1(h)
        h = nonlinearity(h)
        h = self.conv1(h)
        h = h + self.temb_proj(nonlinearity(temb))[:, :, None, None]
        h = self.norm2(h)
        h = nonlinearity(h)
        h = self.dropout(h)
        h = self.conv2(h)

        if self.in_channels != self.out_channels:
            x = self.shortcut(x)
        return x + h


class AttnBlock(nn.Module):
    def __init__(self, in_channels):
        super().__init__()
        self.in_channels = in_channels
        self.norm = Normalize(in_channels)
        self.q = torch.nn.Conv2d(in_channels, in_channels, kernel_size=1, stride=1, padding=0)
        self.k = torch.nn.Conv2d(in_channels, in_channels, kernel_size=1, stride=1, padding=0)
        self.v = torch.nn.Conv2d(in_channels, in_channels, kernel_size=1, stride=1, padding=0)
        self.proj_out = torch.nn.Conv2d(in_channels, in_channels, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        h_ = x
        h_ = self.norm(h_)
        q, k, v = self.q(h_), self.k(h_), self.v(h_)

        b, c, h, w = q.shape
        q = q.reshape(b, c, h * w).permute(0, 2, 1)
        k = k.reshape(b, c, h * w)
        w_ = torch.bmm(q, k) * (int(c) ** (-0.5))
        w_ = torch.nn.functional.softmax(w_, dim=2)

        v = v.reshape(b, c, h * w)
        w_ = w_.permute(0, 2, 1)
        h_ = torch.bmm(v, w_).reshape(b, c, h, w)
        return x + self.proj_out(h_)


# ====================================================
# 2. 条件 UNet (魔改版，支持拼接 Condition)
# ====================================================


class ConditionalUNet(nn.Module):
    """
    魔改自 DDIM 的 Model。
    适配了将 cond_channels 拼接到输入通道中。
    """
    def __init__(self, in_channels, cond_channels, ch=128, out_ch=None, ch_mult=(1, 2, 2, 2), num_res_blocks=2, dropout=0.1):
        super().__init__()
        self.ch = ch
        self.temb_ch = self.ch * 4
        self.num_resolutions = len(ch_mult)
        self.num_res_blocks = num_res_blocks
        out_ch = in_channels if out_ch is None else out_ch

        self.temb = nn.Module()
        self.temb.dense = nn.ModuleList([
            torch.nn.Linear(self.ch, self.temb_ch),
            torch.nn.Linear(self.temb_ch, self.temb_ch),
        ])

        self.conv_in = torch.nn.Conv2d(in_channels + cond_channels, self.ch, kernel_size=3, stride=1, padding=1)

        self.down = nn.ModuleList()
        in_ch_mult = (1,) + tuple(ch_mult)

        block_in = None
        for i_level in range(self.num_resolutions):
            block = nn.ModuleList()
            block_in = ch * in_ch_mult[i_level]
            block_out = ch * ch_mult[i_level]
            for _ in range(self.num_res_blocks):
                block.append(ResnetBlock(in_channels=block_in, out_channels=block_out, temb_channels=self.temb_ch, dropout=dropout))
                block_in = block_out
            down = nn.Module()
            down.block = block
            self.down.append(down)

        self.mid = nn.Module()
        self.mid.block_1 = ResnetBlock(in_channels=block_in, out_channels=block_in, temb_channels=self.temb_ch, dropout=dropout)
        self.mid.attn_1 = AttnBlock(block_in)
        self.mid.block_2 = ResnetBlock(in_channels=block_in, out_channels=block_in, temb_channels=self.temb_ch, dropout=dropout)

        self.up = nn.ModuleList()
        for i_level in reversed(range(self.num_resolutions)):
            block = nn.ModuleList()
            block_out = ch * ch_mult[i_level]
            skip_in = ch * ch_mult[i_level]
            for i_block in range(self.num_res_blocks + 1):
                if i_block == self.num_res_blocks:
                    skip_in = ch * in_ch_mult[i_level]
                block.append(ResnetBlock(in_channels=block_in + skip_in, out_channels=block_out, temb_channels=self.temb_ch, dropout=dropout))
                block_in = block_out
            up = nn.Module()
            up.block = block
            self.up.insert(0, up)

        self.norm_out = Normalize(block_in)
        self.conv_out = torch.nn.Conv2d(block_in, out_ch, kernel_size=3, stride=1, padding=1)

    def forward(self, x, t, cond):
        h = torch.cat([x, cond], dim=1)

        temb = get_timestep_embedding(t, self.ch)
        temb = self.temb.dense[0](temb)
        temb = nonlinearity(temb)
        temb = self.temb.dense[1](temb)

        hs = [self.conv_in(h)]
        for i_level in range(self.num_resolutions):
            for i_block in range(self.num_res_blocks):
                h = self.down[i_level].block[i_block](hs[-1], temb)
                hs.append(h)

        h = hs[-1]
        h = self.mid.block_1(h, temb)
        h = self.mid.attn_1(h)
        h = self.mid.block_2(h, temb)

        for i_level in reversed(range(self.num_resolutions)):
            for i_block in range(self.num_res_blocks + 1):
                h = self.up[i_level].block[i_block](torch.cat([h, hs.pop()], dim=1), temb)

        h = self.norm_out(h)
        h = nonlinearity(h)
        h = self.conv_out(h)

        return h


# ====================================================
# 3. ARP 残差扩散模型封装 (核心逻辑)
# ====================================================


class ARPResidualDiffusion(nn.Module):
    def __init__(self, in_channels, cond_channels, num_timesteps=1000):
        super().__init__()
        self.num_timesteps = num_timesteps

        self.unet = ConditionalUNet(in_channels=in_channels, cond_channels=cond_channels, ch=128)

        betas = torch.linspace(0.0001, 0.02, num_timesteps)
        alphas = 1.0 - betas
        alphas_cumprod = torch.cumprod(alphas, dim=0)

        self.register_buffer('betas', betas)
        self.register_buffer('alphas_cumprod', alphas_cumprod)
        self.register_buffer('sqrt_alphas_cumprod', torch.sqrt(alphas_cumprod))
        self.register_buffer('sqrt_one_minus_alphas_cumprod', torch.sqrt(1. - alphas_cumprod))

    def forward_train(self, future_feat, current_feat, history_feat):
        b = future_feat.size(0)
        device = future_feat.device

        target_residual = future_feat - current_feat
        cond = torch.cat([current_feat, history_feat], dim=1)

        if target_residual.shape[-2:] != cond.shape[-2:]:
            raise ValueError("Residual and condition spatial sizes must match")

        t = torch.randint(0, self.num_timesteps, (b,), device=device).long()

        noise = torch.randn_like(target_residual)
        sqrt_a_t = self.sqrt_alphas_cumprod[t].view(b, 1, 1, 1)
        sqrt_one_minus_a_t = self.sqrt_one_minus_alphas_cumprod[t].view(b, 1, 1, 1)

        x_noisy = sqrt_a_t * target_residual + sqrt_one_minus_a_t * noise

        pred_residual = self.unet(x_noisy, t, cond)

        mse_loss = nn.functional.mse_loss(pred_residual, target_residual)

        return mse_loss

    @torch.no_grad()
    def sample_ddim(self, current_feat, history_feat, ddim_steps=20):
        b, c, h, w = current_feat.shape
        device = current_feat.device

        cond = torch.cat([current_feat, history_feat], dim=1)

        x_t = torch.randn((b, c, h, w), device=device)

        seq = torch.linspace(0, self.num_timesteps - 1, ddim_steps).long().cpu().numpy()
        seq = seq[::-1]

        for i, t_idx in enumerate(seq):
            t = torch.full((b,), t_idx, device=device, dtype=torch.long)

            pred_residual_x0 = self.unet(x_t, t, cond)

            alpha_t = self.alphas_cumprod[t_idx].to(device)
            if i < len(seq) - 1:
                alpha_prev = self.alphas_cumprod[seq[i + 1]].to(device)
            else:
                alpha_prev = torch.tensor(1.0, device=device)

            dir_xt = torch.sqrt(1. - alpha_prev) * ((x_t - torch.sqrt(alpha_t) * pred_residual_x0) / torch.sqrt(1. - alpha_t))

            x_t = torch.sqrt(alpha_prev) * pred_residual_x0 + dir_xt

        predicted_future_feat = current_feat + x_t
        return predicted_future_feat
